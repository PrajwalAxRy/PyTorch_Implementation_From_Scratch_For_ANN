__version__ = '0.1.0'  # Define the version of your package
